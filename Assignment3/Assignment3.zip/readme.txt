To compile you can use type the following into the command line "gcc -o smallsh smallsh.c" OR use the makefile by typing in "make" into the command line.
