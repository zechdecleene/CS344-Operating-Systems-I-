#ifndef ARGS
#define ARGS
#include "room.h"

struct Args{
  struct Room *room;
  int idx;
};

#endif
