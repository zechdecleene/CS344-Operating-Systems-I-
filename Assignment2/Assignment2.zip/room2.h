#ifndef ROOM_TWO
#define ROOM_TWO

struct RoomTypeB{
  char name[32];
  char connections[6][32];
  int num_connections;
  char type[32];
};

#endif
